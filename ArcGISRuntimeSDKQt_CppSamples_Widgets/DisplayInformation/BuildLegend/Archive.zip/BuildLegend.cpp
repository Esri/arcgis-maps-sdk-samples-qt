// [WriteFile Name=BuildLegend, Category=DisplayInformation]
// [Legal]
// Copyright 2018 Esri.

// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// http://www.apache.org/licenses/LICENSE-2.0

// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
// [Legal]

#include "BuildLegend.h"

#include "ui_BuildLegend.h"

#include "Map.h"
#include "ArcGISTiledLayer.h"
#include "ArcGISMapImageLayer.h"
#include "FeatureLayer.h"
#include "ServiceFeatureTable.h"
#include "EncCell.h"
#include "EncDataset.h"
#include "EncLayer.h"
#include "EncExchangeSet.h"
#include "EncEnvironmentSettings.h"

#include <QUrl>

using namespace Esri::ArcGISRuntime;

BuildLegend::BuildLegend(QWidget* parent /* = nullptr */):
  QWidget(parent),
  m_ui(new Ui::BuildLegend)
{
  m_ui->setupUi(this);

  // Create a map using the topo basemap
  m_map = new Map(Basemap::topographic(this), this);
  m_map->setAutoFetchLegendInfos(true);
  // set initial viewpoint
  m_map->setInitialViewpoint(
        Viewpoint(Point(-11e6, 6e6, SpatialReference(3857)), 9e7));


  m_map = new Map(Basemap::nationalGeographic(this), this);

  m_ui->mapView->setMap(m_map);

  // load the ENC exchange set from local data
  QString dataPath("/Users/luca6804/Downloads/ExchangeSetwithoutUpdates/ENC_ROOT/CATALOG.031");
  EncExchangeSet* encExchangeSet = new EncExchangeSet({dataPath}, this);
  connect(encExchangeSet, &EncExchangeSet::doneLoading, this, [this, encExchangeSet](Error e)
  {
      if (!e.isEmpty())
          return;

      // loop through the individual datasets of the exchange set
      for (EncDataset* encDataset : encExchangeSet->datasets()) {
        // create an ENC layer with an ENC cell using the dataset
        EncLayer* encLayer = new EncLayer(new EncCell(encDataset, this), this);
        // add the ENC layer to the map's operational layers to display it
        m_map->operationalLayers()->append(encLayer);
        connect(encLayer, &EncLayer::doneLoading, this, [encLayer, this](Error e)
        {
           if (!e.isEmpty())
               return;

           m_ui->mapView->setViewpointGeometry(encLayer->fullExtent());
        });
      }
  });
  encExchangeSet->load();
}

BuildLegend::~BuildLegend()
{
  delete m_ui;
}
